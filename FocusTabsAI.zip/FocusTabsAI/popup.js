const searchInput = document.getElementById('search-input');
const tabsContainer = document.getElementById('tabs-container');
const startTimerBtn = document.getElementById('start-timer-btn');
const stopTimerBtn = document.getElementById('stop-timer-btn');
const timerDisplay = document.getElementById('timer-display');
const focusTimerHours = document.getElementById('focus-timer-hours');
const focusTimerMinutes = document.getElementById('focus-timer-minutes');

timerDisplay.textContent = '##:##';

searchInput.addEventListener('input', filterTabs);

chrome.tabs.query({}, (tabs) => {
  tabs.forEach((tab) => {
    const tabItem = document.createElement('div');
    tabItem.classList.add('tab-item');
    tabItem.id = tab.id;
    tabItem.draggable = true;

    const tabTitle = document.createElement('span');
    tabTitle.classList.add('tab-title');
    tabTitle.textContent = tab.title;

    const closeTabBtn = document.createElement('button');
    closeTabBtn.classList.add('close-tab-btn');
    closeTabBtn.textContent = '×';
    closeTabBtn.addEventListener('click', (event) => {
      event.stopPropagation();
      chrome.tabs.remove(tab.id);
      tabItem.remove();
    });

    tabItem.appendChild(tabTitle);
    tabItem.appendChild(closeTabBtn);
    tabsContainer.appendChild(tabItem);
  });
});

tabsContainer.addEventListener('click', (e) => {
  const tabItem = e.target.closest('.tab-item');
  if (!tabItem) return;

  const tabId = parseInt(tabItem.id, 10);

  chrome.tabs.get(tabId, (tab) => {
    chrome.windows.update(tab.windowId, { focused: true }, () => {
      chrome.tabs.update(tab.id, { active: true });
    });
  });
});

function filterTabs() {
  const searchTerm = searchInput.value.toLowerCase();
  const tabItems = tabsContainer.querySelectorAll('.tab-item');

  tabItems.forEach((tabItem) => {
    const tabTitle = tabItem.querySelector('.tab-title').textContent.toLowerCase();
    tabItem.style.display = tabTitle.includes(searchTerm) ? '' : 'none';
  });
}

function startTimer() {
  const hours = parseInt(focusTimerHours.value, 10) || 0;
  const minutes = parseInt(focusTimerMinutes.value, 10) || 0;
  const duration = (hours * 60 + minutes) * 60;

  if (duration > 0) {
    chrome.runtime.sendMessage({ message: 'start_timer', duration: duration });
  } else {
    alert('Please select a valid time duration.');
  }
}

function stopTimer() {
  chrome.runtime.sendMessage({ message: 'stop_timer' });
  displayTime(0);
}

startTimerBtn.addEventListener('click', startTimer);
stopTimerBtn.addEventListener('click', stopTimer);

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.message === 'timer_update') {
    displayTime(request.remainingTime);
  }
});

function displayTime(seconds) {
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const remainingSeconds = seconds % 60;
  timerDisplay.textContent = `${hours < 10 ? '0' : ''}${hours}:${minutes < 10 ? '0' : ''}${minutes}:${remainingSeconds < 10 ? '0' : ''}${remainingSeconds}`;
}

document.addEventListener('dragstart', (e) => {
  e.dataTransfer.setData('text/plain', e.target.id);
});

document.addEventListener('dragover', (e) => {
  e.preventDefault();
});

document.addEventListener('drop', (e) => {
  e.preventDefault();
  const target = e.target.closest('.tab-item');
  if (!target) return;

  const sourceId = e.dataTransfer.getData('text/plain');
  const source = document.getElementById(sourceId);
  target.parentNode.insertBefore(source, target.nextSibling);
});

const sortSelect = document.getElementById('sort-select');
sortSelect.addEventListener('change', sortTabs);

function sortTabs() {
  const sortOption = sortSelect.value;
  const tabItems = Array.from(tabsContainer.querySelectorAll('.tab-item'));

  tabItems.sort((a, b) => {
    const aTitle = a.querySelector('.tab-title').textContent;
    const bTitle = b.querySelector('.tab-title').textContent;

    switch (sortOption) {
      case 'title-asc':
        return aTitle.localeCompare(bTitle);
      case 'title-desc':
        return bTitle.localeCompare(aTitle);
      case 'random':
        return Math.random() - 0.5;
      case 'recent':
      default:
        return Number(a.id) - Number(b.id);
    }
  });
  tabItems.forEach((tabItem) => {
    tabsContainer.appendChild(tabItem);
  });
}

focusTimerHours.addEventListener('change', updateTimerDisplay);
focusTimerMinutes.addEventListener('change', updateTimerDisplay);

function updateTimerDisplay() {
  const hours = parseInt(focusTimerHours.value, 10) || 0;
  const minutes = parseInt(focusTimerMinutes.value, 10) || 0;
  displayTime((hours * 60 + minutes) * 60);
}
