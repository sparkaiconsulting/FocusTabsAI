chrome.runtime.onInstalled.addListener(function () {
  // Initialize the extension's storage with default values
});

chrome.tabs.onUpdated.addListener(function (tabId, changeInfo, tab) {
  // Update the tab group data when a tab's title or URL changes
});

chrome.tabs.onRemoved.addListener(function (tabId, removeInfo) {
  // Update the tab group data when a tab is closed
});

let timer;
let remainingTime = 0;

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.message === 'start_timer') {
    clearInterval(timer);
    remainingTime = request.duration;

    timer = setInterval(() => {
      remainingTime--;

      if (remainingTime <= 0) {
        clearInterval(timer);
      }

      chrome.runtime.sendMessage({ message: 'timer_update', remainingTime: remainingTime });
    }, 1000);
  } else if (request.message === 'stop_timer') {
    clearInterval(timer);
    remainingTime = 0;
  }
});
